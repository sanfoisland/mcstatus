### Minecraft Service Status Checker

This code used power my Minecraft services status checker website for a couple
of years. I will not be fixing any issues, or providing any support.

All code released as-is, under [MIT](LICENSE) license.

*`bg.jpg` taken from subtlepatterns.com*
